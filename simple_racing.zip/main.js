// main.js — a compact Three.js + cannon-es racing demo
// Note: this file assumes Three.js and cannon-es are available via CDN module imports.
// When opening index.html from the filesystem in some browsers modules from CDN may be blocked.
// Recommended: host on GitHub Pages or run a local server (e.g., `python -m http.server`).

import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js';
import * as CANNON from 'https://cdn.jsdelivr.net/npm/cannon-es@0.20.0/dist/cannon-es.js';

let scene, camera, renderer, world;
let carBody, chassisMesh, wheelMeshes = [];
let timeStep = 1/60;
let speedDisplay;

init();
animate();

function init(){
  speedDisplay = document.getElementById('speed');
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87CEEB); // sky

  camera = new THREE.PerspectiveCamera(60, window.innerWidth/window.innerHeight, 0.1, 1000);
  camera.position.set(0, 5, -10);

  renderer = new THREE.WebGLRenderer({antialias:true});
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const ambient = new THREE.HemisphereLight(0xffffff, 0x444444, 0.8);
  scene.add(ambient);
  const dir = new THREE.DirectionalLight(0xffffff, 0.6);
  dir.position.set(5,10,7);
  scene.add(dir);

  // Ground / Track
  const groundGeo = new THREE.PlaneGeometry(200, 200);
  const groundMat = new THREE.MeshStandardMaterial({color:0x2e8b57});
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI/2;
  scene.add(ground);

  // Simple track markings
  const track = new THREE.Mesh(new THREE.PlaneGeometry(60, 12), new THREE.MeshStandardMaterial({color:0x444444}));
  track.rotation.x = -Math.PI/2;
  track.position.y = 0.01;
  scene.add(track);

  // Road center line
  const lineGeo = new THREE.PlaneGeometry(60, 0.2);
  const lineMat = new THREE.MeshStandardMaterial({color:0xffff00});
  const line = new THREE.Mesh(lineGeo, lineMat);
  line.rotation.x = -Math.PI/2;
  line.position.y = 0.02;
  scene.add(line);

  // Add some environment objects (boxes)
  for(let i=0;i<30;i++){
    const box = new THREE.Mesh(new THREE.BoxGeometry(1,1,1), new THREE.MeshStandardMaterial({color:0x8b4513}));
    box.position.set((Math.random()-0.5)*80,0.5,(Math.random()-0.5)*80);
    scene.add(box);
  }

  // Physics world
  world = new CANNON.World({gravity: new CANNON.Vec3(0,-9.82,0)});
  const groundBody = new CANNON.Body({
    mass: 0,
    shape: new CANNON.Plane(),
    material: new CANNON.Material({friction:0.9})
  });
  groundBody.quaternion.setFromEuler(-Math.PI/2, 0, 0);
  world.addBody(groundBody);

  // Car chassis (a box)
  const chassisShape = new CANNON.Box(new CANNON.Vec3(1,0.5,2));
  carBody = new CANNON.Body({mass: 150});
  carBody.addShape(chassisShape);
  carBody.position.set(0, 1.2, 0);
  carBody.angularDamping = 0.5;
  world.addBody(carBody);

  // Visual chassis
  const chassisGeo = new THREE.BoxGeometry(2,1,4);
  const chassisMat = new THREE.MeshStandardMaterial({color:0xff0000, metalness:0.4, roughness:0.6});
  chassisMesh = new THREE.Mesh(chassisGeo, chassisMat);
  scene.add(chassisMesh);

  // Simple wheels (visual only) — we attach them to follow physics
  const wheelGeo = new THREE.CylinderGeometry(0.4,0.4,0.3,16);
  const wheelMat = new THREE.MeshStandardMaterial({color:0x222222});
  const wheelPositions = [
    new CANNON.Vec3(-1, 0.6, 1.6),
    new CANNON.Vec3(1, 0.6, 1.6),
    new CANNON.Vec3(-1, 0.6, -1.6),
    new CANNON.Vec3(1, 0.6, -1.6),
  ];
  for(let i=0;i<4;i++){
    const m = new THREE.Mesh(wheelGeo, wheelMat);
    m.rotation.z = Math.PI/2;
    scene.add(m);
    wheelMeshes.push({mesh:m, relPos: wheelPositions[i]});
  }

  // Simple suspension / wheel constraints (approximate)
  // We'll simulate wheel forces by applying forces at wheel positions.
  // Controls & state
  controls = {
    forward: false, back:false, left:false, right:false, handbrake:false
  };

  window.addEventListener('keydown', (e)=>{
    if(e.key==='w' || e.key==='ArrowUp') controls.forward=true;
    if(e.key==='s' || e.key==='ArrowDown') controls.back=true;
    if(e.key==='a' || e.key==='ArrowLeft') controls.left=true;
    if(e.key==='d' || e.key==='ArrowRight') controls.right=true;
    if(e.code==='Space') controls.handbrake=true;
    if(e.key==='r') resetCar();
  });
  window.addEventListener('keyup', (e)=>{
    if(e.key==='w' || e.key==='ArrowUp') controls.forward=false;
    if(e.key==='s' || e.key==='ArrowDown') controls.back=false;
    if(e.key==='a' || e.key==='ArrowLeft') controls.left=false;
    if(e.key==='d' || e.key==='ArrowRight') controls.right=false;
    if(e.code==='Space') controls.handbrake=false;
  });

  window.addEventListener('resize', onWindowResize);
}

function resetCar(){
  carBody.position.set(0,1.2,0);
  carBody.velocity.set(0,0,0);
  carBody.angularVelocity.set(0,0,0);
  carBody.quaternion.set(0,0,0,1);
}

function applyControls(){
  // In world space, find forward direction of the car
  const forward = new CANNON.Vec3(0,0,1);
  carBody.quaternion.vmult(forward, forward); // rotate into world

  // Lateral direction
  const right = new CANNON.Vec3(1,0,0);
  carBody.quaternion.vmult(right, right);

  // Engine/brake force
  let engineForce = 0;
  const maxEngine = 2500; // tune for 'realistic' feel
  if(controls.forward) engineForce = maxEngine;
  if(controls.back) engineForce = -maxEngine*0.5;
  // Apply forces at rear wheels (approx)
  const rearLeft = new CANNON.Vec3(-1,0,-1.6);
  const rearRight= new CANNON.Vec3(1,0,-1.6);
  const forceVec = forward.scale(engineForce);
  carBody.applyForce(forceVec, rearLeft);
  carBody.applyForce(forceVec, rearRight);

  // Steering: rotate the chassis slightly
  const steerAngle = 0.04;
  if(controls.left) carBody.angularVelocity.y += 0.02;
  if(controls.right) carBody.angularVelocity.y -= 0.02;

  // Simple downforce proportional to speed (makes car 'stick')
  const speed = carBody.velocity.length();
  const downforce = Math.min(500 * speed, 5000);
  carBody.applyForce(new CANNON.Vec3(0,-downforce,0), carBody.position);

  // Handbrake
  if(controls.handbrake){
    // increase lateral damping
    carBody.velocity.x *= 0.96;
    carBody.velocity.z *= 0.96;
  }
}

function animate(){
  requestAnimationFrame(animate);
  // step physics
  applyControls();
  world.step(timeStep);

  // sync visuals
  chassisMesh.position.copy(carBody.position);
  chassisMesh.quaternion.copy(carBody.quaternion);

  // update wheel visuals by offsetting from chassis
  for(const w of wheelMeshes){
    const worldPos = new CANNON.Vec3();
    carBody.pointToWorldFrame(w.relPos, worldPos);
    w.mesh.position.set(worldPos.x, worldPos.y - 0.35, worldPos.z);
    // spin wheel according to forward velocity
    const spin = carBody.velocity.length() * 0.5;
    w.mesh.rotation.x += spin * 0.01;
  }

  // camera chase: follow slightly behind and above the car
  const chaseOffset = new THREE.Vector3(0,3,-8).applyQuaternion(new THREE.Quaternion(
    chassisMesh.quaternion.x, chassisMesh.quaternion.y, chassisMesh.quaternion.z, chassisMesh.quaternion.w
  ));
  const desired = new THREE.Vector3().copy(chassisMesh.position).add(chaseOffset);
  camera.position.lerp(desired, 0.08);
  camera.lookAt(chassisMesh.position);

  // HUD
  speedDisplay.textContent = 'Speed: ' + Math.round(carBody.velocity.length()*3.6) + ' km/h';

  renderer.render(scene, camera);
}

function onWindowResize(){
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}
