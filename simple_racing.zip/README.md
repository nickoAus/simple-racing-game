# Simple Racing — Web (Three.js + cannon-es)

This is a compact, educational demo of a 3D car with basic physics using Three.js for graphics and cannon-es for physics.

Features:
- Chassis with simple physics body
- Engine force applied at rear wheels
- Basic steering and downforce
- Camera chase and HUD

How to run:
1. Serve the folder using a static server (recommended):
   - `python -m http.server` (Python 3) and open http://localhost:8000
   - or push this repo to GitHub and enable Pages
2. Controls:
   - W / Up Arrow: accelerate
   - S / Down Arrow: reverse / brake
   - A / Left Arrow: steer left
   - D / Right Arrow: steer right
   - Space: handbrake
   - R: reset position

Notes:
- For more realism, replace the simplified physics with a full wheel-constraint vehicle (e.g., raycast vehicle),
  add tire friction models, suspension, better visual assets, and sound.
- The CDN imports used in `main.js` are suitable for hosting (GitHub Pages). If you run from local files,
  some browsers may block module CDN loads: use a local server.

License: MIT
